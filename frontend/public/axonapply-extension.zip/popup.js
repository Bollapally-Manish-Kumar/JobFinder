/**
 * AxonApply™ Popup Script
 * - Allows user to start/stop per page
 * - Sends profile data to content script
 */

const statusEl = document.getElementById('status');
const connectionStatusEl = document.getElementById('connectionStatus');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');

const setStatus = (text, color = '#9ca3af') => {
  statusEl.textContent = text;
  statusEl.style.color = color;
};

const setConnectionStatus = (text, color = '#9ca3af') => {
  connectionStatusEl.textContent = text;
  connectionStatusEl.style.color = color;
};

const sendMessage = (message) => {
  chrome.runtime.sendMessage(message, (response) => {
    if (!response?.success) {
      setStatus(response?.error || 'Action failed', '#f97316');
      return;
    }
    setStatus('AxonApply™ updated', '#22c55e');
  });
};

startBtn.addEventListener('click', () => {
  sendMessage({
    type: 'AXONAPPLY_START',
    // profile/resume/preferences are provided via Connect from the web app
  });
});

stopBtn.addEventListener('click', () => {
  sendMessage({ type: 'AXONAPPLY_STOP' });
});

// Initialize UI state
chrome.runtime.sendMessage({ type: 'AXONAPPLY_GET_STATE' }, (response) => {
  if (response?.success && response.state?.enabled) {
    setStatus('AxonApply™ is running on this tab', '#22c55e');
  } else {
    setStatus('AxonApply™ is idle');
  }

  if (response?.success) {
    const connected = !!response.connected;
    const lastError = response.state?.lastError;

    if (lastError) {
      setConnectionStatus('Reconnect required', '#f97316');
      return;
    }

    setConnectionStatus(connected ? 'Connected to GoAxonAI' : 'Not connected', connected ? '#22c55e' : '#9ca3af');
  }
});
