/**
 * AxonApply™ Connector (runs only on GoAxonAI domains)
 * Purpose: Receive AXONAPPLY_CONNECT from the hosted app and pass to background.
 * Safety: No DOM automation. No form interaction.
 */

(() => {
  const ALLOWED_ORIGINS = [
    'https://www.goaxonai.in',
    'https://app.goaxonai.in',
    // Dev-only (localhost)
    'http://localhost:5173',
    'http://127.0.0.1:5173'
  ];

  const isValidPayload = (payload) => {
    return !!(
      payload?.authToken &&
      payload?.profile?.email
    );
  };

  // Check if extension context is still valid
  const isExtensionValid = () => {
    try {
      return !!(chrome?.runtime?.id);
    } catch {
      return false;
    }
  };

  window.addEventListener('message', (event) => {
    if (!ALLOWED_ORIGINS.includes(event.origin)) return;
    if (event?.data?.type !== 'AXONAPPLY_CONNECT') return;

    const payload = event.data.payload || {};
    if (!isValidPayload(payload)) {
      console.warn('AxonApply connector: invalid payload');
      return;
    }

    // Check extension context before sending
    if (!isExtensionValid()) {
      console.warn('AxonApply: Extension was reloaded. Please refresh this page.');
      window.postMessage({ 
        type: 'AXONAPPLY_ERROR', 
        error: 'Extension was reloaded. Please refresh this page and try again.' 
      }, '*');
      return;
    }

    try {
      chrome.runtime.sendMessage({
        type: 'AXONAPPLY_CONNECT',
        profile: payload.profile,
        resume: payload.resume,
        preferences: payload.preferences,
        authToken: payload.authToken
      });
    } catch (err) {
      console.warn('AxonApply: Extension context error:', err.message);
      window.postMessage({ 
        type: 'AXONAPPLY_ERROR', 
        error: 'Extension connection lost. Please refresh this page.' 
      }, '*');
    }
  });

  // Relay background acknowledgement to the web app
  chrome.runtime.onMessage.addListener((message) => {
    if (!isExtensionValid()) return;
    
    try {
      if (message?.type === 'AXONAPPLY_CONNECTED') {
        window.postMessage({ type: 'AXONAPPLY_CONNECTED_ACK' }, '*');
      }
    } catch (err) {
      console.warn('AxonApply: Message relay error:', err.message);
    }
  });
})();
