/**
 * AxonApply™ Background Service Worker
 * - Injects content script on demand
 * - Maintains per-tab state (session only)
 * - Proxies secure API calls to GoAxonAI backend
 */

const TAB_STATE_KEY = 'axonapply_tab_state';
const SESSION_TOKEN_KEY = 'axonapply_session_token';
const SESSION_PROFILE_KEY = 'axonapply_session_profile';
const DEFAULT_API_BASE = 'https://www.goaxonai.in/api';

const getActiveTab = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
};

const getTabState = async (tabId) => {
  const data = await chrome.storage.session.get(TAB_STATE_KEY);
  const state = data[TAB_STATE_KEY] || {};
  return state[tabId] || { enabled: false, connectedAt: null, lastError: null };
};

const setTabState = async (tabId, nextState) => {
  const data = await chrome.storage.session.get(TAB_STATE_KEY);
  const state = data[TAB_STATE_KEY] || {};
  state[tabId] = { ...(state[tabId] || {}), ...nextState };
  await chrome.storage.session.set({ [TAB_STATE_KEY]: state });
};

const setSessionToken = async (token) => {
  if (!token) return;
  await chrome.storage.session.set({ [SESSION_TOKEN_KEY]: token });
};

const getSessionToken = async () => {
  const data = await chrome.storage.session.get(SESSION_TOKEN_KEY);
  return data[SESSION_TOKEN_KEY] || null;
};

const setSessionProfile = async (payload) => {
  if (!payload) return;
  await chrome.storage.session.set({ [SESSION_PROFILE_KEY]: payload });
};

const getSessionProfile = async () => {
  const data = await chrome.storage.session.get(SESSION_PROFILE_KEY);
  return data[SESSION_PROFILE_KEY] || null;
};

const injectContentScript = async (tabId) => {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['contentScript.js']
    });
  } catch (error) {
    // Content script might already be injected; ignore duplicate errors
    console.warn('AxonApply inject warning:', error?.message || error);
  }
};

const postToBackend = async (endpoint, payload, token) => {
  const authToken = token || await getSessionToken();
  if (!authToken) {
    return { success: false, error: 'Missing auth token' };
  }

  const response = await fetch(`${DEFAULT_API_BASE}${endpoint}`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify(payload)
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    return { success: false, error: errorText || 'Request failed' };
  }

  return response.json();
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    // Basic sender validation (prevents other extensions from spoofing)
    if (sender?.id && sender.id !== chrome.runtime.id) {
      return;
    }

    if (message?.type === 'AXONAPPLY_INJECT') {
      const tab = await getActiveTab();
      if (!tab?.id) return sendResponse({ success: false, error: 'No active tab' });
      await injectContentScript(tab.id);
      return sendResponse({ success: true });
    }

    if (message?.type === 'AXONAPPLY_START') {
      const tab = await getActiveTab();
      if (!tab?.id) return sendResponse({ success: false, error: 'No active tab' });

      await injectContentScript(tab.id);

      const existingState = await getTabState(tab.id);
      const sessionProfile = await getSessionProfile();
      const profile = message.profile || existingState.profile || sessionProfile?.profile;
      const resume = message.resume || existingState.resume || sessionProfile?.resume;
      const preferences = message.preferences || existingState.preferences || sessionProfile?.preferences;

      if (!profile) {
        return sendResponse({ success: false, error: 'Connect your GoAxonAI profile first.' });
      }

      await setTabState(tab.id, { enabled: true, profile, resume, preferences });

      if (message.authToken) {
        await setSessionToken(message.authToken);
      }

      chrome.tabs.sendMessage(tab.id, {
        type: 'AXONAPPLY_START',
        profile,
        resume,
        preferences
      });

      return sendResponse({ success: true });
    }

    if (message?.type === 'AXONAPPLY_CONNECT') {
      const tab = await getActiveTab();
      if (!tab?.id) return sendResponse({ success: false, error: 'No active tab' });

      await injectContentScript(tab.id);
      await setTabState(tab.id, {
        profile: message.profile,
        resume: message.resume,
        preferences: message.preferences,
        connectedAt: Date.now(),
        lastError: null
      });

      await setSessionProfile({
        profile: message.profile,
        resume: message.resume,
        preferences: message.preferences,
        connectedAt: Date.now()
      });

      if (message.authToken) {
        await setSessionToken(message.authToken);
      }

      chrome.tabs.sendMessage(tab.id, { type: 'AXONAPPLY_CONNECTED' });
      return sendResponse({ success: true });
    }

    if (message?.type === 'AXONAPPLY_STOP') {
      const tab = await getActiveTab();
      if (!tab?.id) return sendResponse({ success: false, error: 'No active tab' });

      await setTabState(tab.id, { enabled: false });
      chrome.tabs.sendMessage(tab.id, { type: 'AXONAPPLY_STOP' });
      return sendResponse({ success: true });
    }

    if (message?.type === 'AXONAPPLY_GET_STATE') {
      const tab = await getActiveTab();
      if (!tab?.id) return sendResponse({ success: false, error: 'No active tab' });

      const state = await getTabState(tab.id);
      const sessionProfile = await getSessionProfile();
      return sendResponse({ success: true, state, connected: !!sessionProfile });
    }

    if (message?.type === 'AXONAPPLY_LOG_EVENT') {
      const result = await postToBackend('/axon-apply/events', message.payload, message.authToken);

      // Update tab state error on auth failures
      const tab = await getActiveTab();
      if (tab?.id && !result?.success) {
        await setTabState(tab.id, { lastError: result.error || 'Unknown error' });
      }

      return sendResponse(result);
    }

    return sendResponse({ success: false, error: 'Unknown message' });
  })();

  return true; // keep channel open for async response
});
