/**
 * AxonApply™ Content Script
 * - Detects job application form fields
 * - Maps fields with semantic matching
 * - Autofills using user profile data
 * - Provides Review & Submit UI
 * - Never bypasses captchas or submits forms
 */

(() => {
  let enabled = false;
  let currentProfile = null;
  let currentResume = null;
  let currentPreferences = null;
  let panelEl = null;
  let submitListenerAttached = false;

  const ALLOWED_ORIGINS = [
    'https://www.goaxonai.in',
    'https://app.goaxonai.in',
    // Dev-only (localhost)
    'http://localhost:5173',
    'http://127.0.0.1:5173'
  ];

  // -----------------------------
  // Utilities
  // -----------------------------
  const normalize = (value) => (value || '').toString().trim().toLowerCase();
  const uniq = (arr) => Array.from(new Set(arr.filter(Boolean)));

  const getLabelText = (input) => {
    const id = input.getAttribute('id');
    if (id) {
      const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (label) return label.textContent?.trim();
    }

    const parentLabel = input.closest('label');
    if (parentLabel) return parentLabel.textContent?.trim();

    return '';
  };

  const getFieldMeta = (input) => {
    const label = getLabelText(input);
    const placeholder = input.getAttribute('placeholder') || '';
    const ariaLabel = input.getAttribute('aria-label') || '';
    const name = input.getAttribute('name') || '';
    const id = input.getAttribute('id') || '';
    const type = input.getAttribute('type') || input.tagName.toLowerCase();

    return {
      element: input,
      label,
      placeholder,
      ariaLabel,
      name,
      id,
      type,
      combinedText: normalize([label, placeholder, ariaLabel, name, id].join(' '))
    };
  };

  const getFormFields = () => {
    const inputs = Array.from(document.querySelectorAll('input, select, textarea'))
      .filter((el) => !el.disabled && el.offsetParent !== null);
    return inputs.map(getFieldMeta);
  };

  const setNativeValue = (element, value) => {
    try {
      const lastValue = element.value;
      element.value = value;
      const event = new Event('input', { bubbles: true });
      element.dispatchEvent(event);

      // Trigger change event too (some forms rely on it)
      if (lastValue !== value) {
        const changeEvent = new Event('change', { bubbles: true });
        element.dispatchEvent(changeEvent);
      }
    } catch (error) {
      console.warn('AxonApply setNativeValue error:', error?.message || error);
    }
  };

  const hasCaptcha = () => {
    // Strict checks only for real captcha widgets to avoid false positives
    return !!(
      document.querySelector('iframe[src*="recaptcha" i]') ||
      document.querySelector('iframe[src*="hcaptcha" i]') ||
      document.querySelector('.g-recaptcha, [data-sitekey]') ||
      document.querySelector('.h-captcha, .hcaptcha-box')
    );
  };

  // -----------------------------
  // Field Mapping Engine
  // -----------------------------
  const FIELD_KEYWORDS = {
    firstName: ['first name', 'firstname', 'first_name', 'fname', 'given name'],
    lastName: ['last name', 'lastname', 'last_name', 'lname', 'surname', 'family name'],
    fullName: ['full name', 'fullname', 'full_name', 'your name'],
    email: ['email', 'e-mail', 'email address', 'emailaddress'],
    phone: ['phone', 'mobile', 'contact', 'whatsapp', 'telephone', 'cell', 'phone number'],
    country: ['country', 'nation', 'country code'],
    city: ['city', 'location', 'town', 'place'],
    address: ['address', 'street', 'postal', 'zip'],
    linkedin: ['linkedin', 'linked in', 'profile url'],
    portfolio: ['portfolio', 'website', 'personal site', 'github'],
    experience: ['experience', 'years', 'yoe', 'work experience', 'years of experience'],
    currentCompany: ['current company', 'employer', 'company name', 'organization'],
    currentTitle: ['current title', 'job title', 'designation', 'position', 'role'],
    salary: ['salary', 'expected salary', 'compensation', 'ctc', 'current salary'],
    noticePeriod: ['notice period', 'notice', 'availability', 'start date', 'join date'],
    resume: ['resume', 'cv', 'curriculum vitae', 'upload resume', 'attachment', 'upload cv']
  };

  const scoreField = (fieldMeta, keywords) => {
    const text = fieldMeta.combinedText;
    if (!text) return 0;

    let score = 0;
    keywords.forEach((keyword) => {
      const key = normalize(keyword);
      if (text === key) score += 1.0;
      if (text.includes(key)) score += 0.6;
      if (fieldMeta.label && normalize(fieldMeta.label).includes(key)) score += 0.7;
      if (fieldMeta.placeholder && normalize(fieldMeta.placeholder).includes(key)) score += 0.6;
      if (fieldMeta.name && normalize(fieldMeta.name).includes(key)) score += 0.6;
      if (fieldMeta.id && normalize(fieldMeta.id).includes(key)) score += 0.6;
    });

    // Normalize to 0..1
    return Math.min(1, score / 2.5);
  };

  const buildFieldMappings = (fields) => {
    const mappings = [];
    const ambiguities = [];
    const usedFields = new Set(); // Prevent same field from being mapped twice

    const targets = Object.keys(FIELD_KEYWORDS);
    targets.forEach((target) => {
      const candidates = fields
        .filter((field) => !usedFields.has(field.element))
        .map((field) => {
          const score = scoreField(field, FIELD_KEYWORDS[target]);
          return { field, score };
        }).sort((a, b) => b.score - a.score);

      const best = candidates[0];
      if (!best || best.score < 0.45) {
        ambiguities.push({ target, candidates: candidates.slice(0, 3) });
        return;
      }

      // If top two are too close, mark ambiguous (but still use best)
      if (candidates[1] && (best.score - candidates[1].score) < 0.1) {
        ambiguities.push({ target, candidates: candidates.slice(0, 3) });
      }

      usedFields.add(best.field.element);
      mappings.push({ target, field: best.field, confidence: best.score });
    });

    return { mappings, ambiguities };
  };

  // -----------------------------
  // Decision Engine
  // -----------------------------
  const decideAxonApply = ({ jobMeta, preferences, profile, formMeta }) => {
    const reasons = [];
    const decision = { decision: 'ASK_USER', reasonCodes: [] };

    if (jobMeta?.requiresReferral) {
      reasons.push('REQUIRES_REFERRAL');
    }

    if (jobMeta?.isPaid) {
      reasons.push('PAID_APPLICATION');
    }

    if (formMeta?.customQuestionCount > 8) {
      reasons.push('TOO_MANY_CUSTOM_QUESTIONS');
    }

    if (!profile?.email || !profile?.phone) {
      reasons.push('MISSING_CRITICAL_PROFILE');
    }

    if (jobMeta?.matchScore !== undefined && jobMeta.matchScore < (preferences?.minMatchScore ?? 0.65)) {
      reasons.push('LOW_MATCH_SCORE');
    }

    if (jobMeta?.location && preferences?.locations?.length) {
      const match = preferences.locations.some((loc) => normalize(jobMeta.location).includes(normalize(loc)));
      if (!match) reasons.push('LOCATION_MISMATCH');
    }

    if (jobMeta?.role && preferences?.roles?.length) {
      const match = preferences.roles.some((role) => normalize(jobMeta.role).includes(normalize(role)));
      if (!match) reasons.push('ROLE_MISMATCH');
    }

    if (reasons.length > 0) {
      const skipReasons = ['REQUIRES_REFERRAL', 'PAID_APPLICATION', 'TOO_MANY_CUSTOM_QUESTIONS', 'MISSING_CRITICAL_PROFILE'];
      const shouldSkip = reasons.some((r) => skipReasons.includes(r));
      decision.decision = shouldSkip ? 'SKIP' : 'ASK_USER';
      decision.reasonCodes = reasons;
      return decision;
    }

    decision.decision = 'APPLY';
    decision.reasonCodes = ['MEETS_CRITERIA'];
    return decision;
  };

  // -----------------------------
  // Core Assist Logic
  // -----------------------------
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const humanDelay = async () => {
    const ms = 180 + Math.floor(Math.random() * 420);
    await sleep(ms);
  };

  const fillFields = async (profile, resume) => {
    const fields = getFormFields();
    console.log('[AxonApply] Found form fields:', fields.map(f => ({ 
      label: f.label, 
      name: f.name, 
      id: f.id, 
      type: f.type,
      combined: f.combinedText 
    })));
    
    const { mappings, ambiguities } = buildFieldMappings(fields);
    console.log('[AxonApply] Field mappings:', mappings.map(m => ({ 
      target: m.target, 
      fieldLabel: m.field.label,
      confidence: m.confidence 
    })));

    // Parse fullName into first/last if needed
    let firstName = profile?.firstName || '';
    let lastName = profile?.lastName || '';
    if (!firstName && !lastName && profile?.fullName) {
      const parts = profile.fullName.trim().split(/\s+/);
      firstName = parts[0] || '';
      lastName = parts.slice(1).join(' ') || '';
    }
    
    console.log('[AxonApply] Profile values:', { 
      firstName, 
      lastName, 
      email: profile?.email,
      phone: profile?.phone,
      city: profile?.city,
      country: profile?.country
    });

    const filled = [];
    const skipped = [];

    for (const { target, field } of mappings) {
      try {
        let didFill = false;
        
        // Name fields
        if (target === 'firstName') {
          if (firstName) {
            setNativeValue(field.element, firstName);
            didFill = true;
          }
        }
        if (target === 'lastName') {
          if (lastName) {
            setNativeValue(field.element, lastName);
            didFill = true;
          }
        }
        if (target === 'fullName') {
          const fullNameValue = profile?.fullName || `${firstName} ${lastName}`.trim();
          if (fullNameValue) {
            setNativeValue(field.element, fullNameValue);
            didFill = true;
          }
        }

        // Contact fields
        if (target === 'email') {
          if (profile?.email) {
            setNativeValue(field.element, profile.email);
            didFill = true;
          }
        }
        if (target === 'phone') {
          if (profile?.phone) {
            setNativeValue(field.element, profile.phone);
            didFill = true;
          }
        }

        // Location fields
        if (target === 'country') {
          if (profile?.country) {
            if (field.element.tagName === 'SELECT') {
              selectOptionByText(field.element, profile.country);
            } else {
              setNativeValue(field.element, profile.country);
            }
            didFill = true;
          }
        }
        if (target === 'city') {
          const cityValue = profile?.city || profile?.location;
          if (cityValue) {
            setNativeValue(field.element, cityValue);
            didFill = true;
          }
        }
        if (target === 'address') {
          if (profile?.address) {
            setNativeValue(field.element, profile.address);
            didFill = true;
          }
        }

        // Professional links
        if (target === 'linkedin') {
          if (profile?.linkedin) {
            setNativeValue(field.element, profile.linkedin);
            didFill = true;
          }
        }
        if (target === 'portfolio') {
          const portfolioValue = profile?.portfolio || profile?.github;
          if (portfolioValue) {
            setNativeValue(field.element, portfolioValue);
            didFill = true;
          }
        }

        // Work details
        if (target === 'experience') {
          if (profile?.experienceYears !== undefined && profile?.experienceYears !== '') {
            setNativeValue(field.element, profile.experienceYears);
            didFill = true;
          }
        }
        if (target === 'currentCompany') {
          if (profile?.currentCompany) {
            setNativeValue(field.element, profile.currentCompany);
            didFill = true;
          }
        }
        if (target === 'currentTitle') {
          const titleValue = profile?.currentTitle || profile?.headline;
          if (titleValue) {
            setNativeValue(field.element, titleValue);
            didFill = true;
          }
        }
        if (target === 'salary') {
          if (profile?.expectedSalary) {
            setNativeValue(field.element, profile.expectedSalary);
            didFill = true;
          }
        }
        if (target === 'noticePeriod') {
          if (profile?.noticePeriod) {
            setNativeValue(field.element, profile.noticePeriod);
            didFill = true;
          }
        }

        if (didFill) {
          filled.push(target);
        } else {
          skipped.push({ target, reason: 'no profile data' });
        }
        
        await humanDelay();
      } catch (error) {
        console.warn('AxonApply fill error:', error?.message || error);
        skipped.push({ target, reason: error?.message });
      }
    }
    
    console.log('[AxonApply] Filled:', filled);
    console.log('[AxonApply] Skipped:', skipped);

    // Resume upload handling
    const resumeField = mappings.find((m) => m.target === 'resume');
    if (resumeField?.field?.element) {
      try {
        const input = resumeField.field.element;
        if (resume?.fileBase64 && resume?.fileName) {
          const file = base64ToFile(resume.fileBase64, resume.fileName, resume?.fileType || 'application/pdf');
          const dataTransfer = new DataTransfer();
          dataTransfer.items.add(file);
          input.files = dataTransfer.files;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
          // Prompt user to choose file manually
          input.classList.add('axonapply-highlight');
        }
      } catch (error) {
        console.warn('AxonApply resume upload error:', error?.message || error);
      }
    }

    return { mappings, ambiguities, filled, skipped };
  };

  // Helper to select dropdown option by text
  const selectOptionByText = (selectEl, text) => {
    const normalizedText = normalize(text);
    const options = Array.from(selectEl.options);
    
    // Try exact match first
    let match = options.find(opt => normalize(opt.text) === normalizedText || normalize(opt.value) === normalizedText);
    
    // Try partial match
    if (!match) {
      match = options.find(opt => normalize(opt.text).includes(normalizedText) || normalizedText.includes(normalize(opt.text)));
    }
    
    if (match) {
      selectEl.value = match.value;
      selectEl.dispatchEvent(new Event('change', { bubbles: true }));
    }
  };

  const base64ToFile = (base64, fileName, mimeType) => {
    const byteString = atob(base64.split(',')[1] || base64);
    const byteArray = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
      byteArray[i] = byteString.charCodeAt(i);
    }
    return new File([byteArray], fileName, { type: mimeType });
  };

  // -----------------------------
  // UI - Review & Submit Panel
  // -----------------------------
  const createPanel = () => {
    if (panelEl) return;

    const style = document.createElement('style');
    style.textContent = `
      .axonapply-panel {
        position: fixed;
        top: 16px;
        right: 16px;
        z-index: 999999;
        background: #0f1115;
        color: #fff;
        border: 1px solid rgba(255,165,0,0.4);
        border-radius: 12px;
        padding: 14px;
        width: 280px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        font-family: system-ui, -apple-system, sans-serif;
      }
      .axonapply-panel h4 { margin: 0 0 6px 0; font-size: 14px; }
      .axonapply-panel p { margin: 0 0 10px 0; font-size: 12px; color: #a1a1aa; }
      .axonapply-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 10px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        font-size: 12px;
      }
      .axonapply-primary { background: #f59e0b; color: #000; font-weight: 600; }
      .axonapply-secondary { background: #1f2937; color: #fff; border: 1px solid #374151; }
      .axonapply-highlight { outline: 2px solid #f59e0b !important; outline-offset: 2px; }
      .axonapply-warning { color: #f97316; font-size: 12px; margin-top: 6px; }
    `;
    document.head.appendChild(style);

    panelEl = document.createElement('div');
    panelEl.className = 'axonapply-panel';
    panelEl.innerHTML = `
      <h4>AxonApply™ Assist</h4>
      <p>Fills fields with your data. You review & submit.</p>
      <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <button class="axonapply-btn axonapply-primary" id="axonapply-review">Review & Submit</button>
        <button class="axonapply-btn axonapply-secondary" id="axonapply-stop">Stop</button>
      </div>
      <div class="axonapply-warning" id="axonapply-warning" style="display:none;"></div>
    `;

    document.body.appendChild(panelEl);

    panelEl.querySelector('#axonapply-review').addEventListener('click', () => {
      highlightSubmitButton();
    });

    panelEl.querySelector('#axonapply-stop').addEventListener('click', () => {
      stopAxonApply();
    });
  };

  const highlightSubmitButton = () => {
    const submit = document.querySelector('button[type="submit"], input[type="submit"]');
    if (submit) {
      submit.classList.add('axonapply-highlight');
      submit.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    showWarning('Review all details and click Submit yourself.');
  };

  const showWarning = (message) => {
    const warningEl = panelEl?.querySelector('#axonapply-warning');
    if (!warningEl) return;
    warningEl.textContent = message;
    warningEl.style.display = 'block';
  };

  const removePanel = () => {
    if (panelEl) {
      panelEl.remove();
      panelEl = null;
    }
    document.querySelectorAll('.axonapply-highlight').forEach((el) => el.classList.remove('axonapply-highlight'));
  };

  const attachSubmitListener = () => {
    if (submitListenerAttached) return;
    const form = document.querySelector('form');
    if (!form) return;

    form.addEventListener('submit', () => {
      if (!currentProfile?.jobMeta) return;
      chrome.runtime.sendMessage({
        type: 'AXONAPPLY_LOG_EVENT',
        payload: {
          jobTitle: currentProfile.jobMeta?.title || 'Unknown Role',
          company: currentProfile.jobMeta?.company || 'Unknown Company',
          platform: currentProfile.jobMeta?.platform || 'Unknown Platform',
          jobUrl: window.location.href,
          resumeVersion: currentResume?.version || null,
          status: 'APPLIED',
          decision: 'APPLY',
          reasonCodes: ['USER_SUBMITTED']
        }
      });
    }, { once: false });

    submitListenerAttached = true;
  };

  const startAxonApply = async ({ profile, resume, preferences }) => {
    if (!profile) {
      console.warn('AxonApply: Missing profile data');
      return;
    }

    console.log('[AxonApply] Starting with profile:', profile);

    enabled = true;
    currentProfile = profile;
    currentResume = resume || null;
    currentPreferences = preferences || null;

    createPanel();

    if (hasCaptcha()) {
      // Warn user, but allow safe field fills (no captcha interaction)
      showWarning('Captcha detected. AxonApply will not interact with it, but can fill other fields.');
    }

    const { mappings, ambiguities } = await fillFields(currentProfile, currentResume);
    
    // Log what was filled
    const filledFields = mappings.map(m => m.target);
    const unfilled = ambiguities.map(a => a.target);
    console.log('[AxonApply] Filled fields:', filledFields);
    console.log('[AxonApply] Unfilled/ambiguous:', unfilled);

    if (ambiguities.length > 0 || mappings.length === 0) {
      const msg = mappings.length === 0 
        ? 'Could not detect form fields. Please fill manually.'
        : 'Some fields are ambiguous. Please review before submitting.';
      showWarning(msg);
    } else {
      showWarning(`Filled ${mappings.length} fields. Please review before submitting.`);
    }

    // Optional decision engine (non-blocking recommendation)
    if (currentProfile?.jobMeta) {
      const decision = decideAxonApply({
        jobMeta: currentProfile.jobMeta,
        preferences: currentPreferences,
        profile: currentProfile,
        formMeta: {
          customQuestionCount: document.querySelectorAll('textarea, select').length
        }
      });

      if (decision.decision === 'SKIP') {
        showWarning('AxonApply recommends skipping this job.');
      }
    }

    // Attach submit listener AFTER user starts AxonApply
    attachSubmitListener();
  };

  const stopAxonApply = () => {
    enabled = false;
    currentProfile = null;
    currentResume = null;
    currentPreferences = null;
    removePanel();
  };

  // -----------------------------
  // Message Listeners
  // -----------------------------
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'AXONAPPLY_START') {
      startAxonApply({
        profile: message.profile,
        resume: message.resume,
        preferences: message.preferences
      });
    }

    if (message?.type === 'AXONAPPLY_STOP') {
      stopAxonApply();
    }

    if (message?.type === 'AXONAPPLY_CONNECTED') {
      window.postMessage({ type: 'AXONAPPLY_CONNECTED_ACK' }, '*');
    }
  });

  // Allow web app to connect profile data via window messaging
  window.addEventListener('message', (event) => {
    if (!ALLOWED_ORIGINS.includes(event.origin)) return;
    if (event?.data?.type === 'AXONAPPLY_CONNECT') {
      const payload = event.data.payload || {};
      if (!payload?.authToken || !payload?.profile?.email) {
        console.warn('AxonApply: Invalid connect payload');
        return;
      }
      chrome.runtime.sendMessage({
        type: 'AXONAPPLY_CONNECT',
        profile: payload.profile,
        resume: payload.resume,
        preferences: payload.preferences,
        authToken: payload.authToken
      });
    }
  });

  // Optional direct start (for internal testing only)
  window.addEventListener('message', (event) => {
    if (event?.data?.type === 'AXONAPPLY_PROFILE') {
      startAxonApply(event.data.payload || {});
    }
  });
})();
